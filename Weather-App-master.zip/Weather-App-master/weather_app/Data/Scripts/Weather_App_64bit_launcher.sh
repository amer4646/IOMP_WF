#!/bin/bash

./Weather_App_64bit
