To use this application on a 64bit Linux system:

1. Unpack the archive.
2. Use Weather_App_64bit_Launcher.sh to run the app. 
(You have to enable running executable text files in Files/Preferences/Behavior - set to run them or ask what to do.)
Or:
1. Open terminal in the folder where you have unpacked the archive.
2. Run ./Weather_App_64bit in the terminal.
Enjoy !
